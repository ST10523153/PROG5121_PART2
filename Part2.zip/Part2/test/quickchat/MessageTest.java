package quickchat;

// Import JUnit testing framework
import org.junit.Before;      // Setup method annotation
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import part2.Message;

/**
 * MessageTest Class
 * Purpose: Unit tests for Message class functionality
 * Tests message validation, creation, and formatting
 */
public class MessageTest {
    
    // Test message object used across tests
    private Message testMessage;
    
    // ============ SETUP METHOD ============
    /**
     * Runs before each test to create fresh test data
     * Resets counters and creates a sample message
     */
    @Before
    public void setUp() {
        // Reset static counter to 0 for clean test state
        Message.resetCounters();
        
        // Create a test message with sample data
        // Uses the exact test data from the assignment
        testMessage = new Message(1, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
    }
    
    // ============ TEST 1: Message Length Success ============
    /**
     * Tests that short messages (under 250 chars) are accepted
     */
    @Test
    public void testMessageLengthSuccess() {
        // Test with short message
        String result = Message.validateMessageLength("Short message");
        
        // Should return success message
        assertEquals("Message ready to send.", result);
    }
    
    // ============ TEST 2: Message Length Failure ============
    /**
     * Tests that messages over 250 characters are rejected
     * Creates a 260-character message using a loop
     */
    @Test
    public void testMessageLengthFailure() {
        // StringBuilder is efficient for building long strings
        StringBuilder longMsg = new StringBuilder();
        
        // Loop 260 times, adding 'a' each time
        // Result: "aaaaaaaaaa..." (260 characters)
        for (int i = 0; i < 260; i++) {
            longMsg.append("a");
        }
        
        // Validate the long message
        String result = Message.validateMessageLength(longMsg.toString());
        
        // assertTrue checks that the condition is true
        // .contains() checks if the message includes the text
        assertTrue(result.contains("exceeds 250 characters by 10"));
    }
    
    // ============ TEST 3: Recipient Number Success ============
    /**
     * Tests that valid international phone numbers are accepted
     */
    @Test
    public void testRecipientNumberSuccess() {
        // Create message with valid recipient number
        Message msg = new Message(1, "+27718693002", "Test");
        
        // Check recipient validation
        String result = msg.checkRecipientCell();
        
        // Should return success
        assertEquals("Cell phone number successfully captured.", result);
    }
    
    // ============ TEST 4: Recipient Number Failure ============
    /**
     * Tests that invalid phone numbers are rejected
     * Invalid because: no + prefix and no country code
     */
    @Test
    public void testRecipientNumberFailure() {
        // Create message with local number (invalid format)
        Message msg = new Message(1, "08575975889", "Test");
        
        // Check recipient validation
        String result = msg.checkRecipientCell();
        
        // Should return error message
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", result);
    }
    
    // ============ TEST 5: Message ID Created ============
    /**
     * Tests that Message ID is automatically generated
     * Should be 10 digits long and not null
     */
    @Test
    public void testMessageIDCreated() {
        // Get the generated message ID
        String messageID = testMessage.getMessageID();
        
        // assertNotNull - passes if object is not null
        assertNotNull(messageID);
        
        // Check length is exactly 10 characters
        assertEquals(10, messageID.length());
        
        // Print for verification (visible in test output)
        System.out.println("Message ID generated: " + messageID);
    }
    
    // ============ TEST 6: Message Hash Correct ============
    /**
     * Tests that message hash follows required format
     * Format should be: "XX:Y:FIRSTLAST"
     */
    @Test
    public void testMessageHashCorrect() {
        // Get the generated hash
        String hash = testMessage.getMessageHash();
        
        // Verify not null
        assertNotNull(hash);
        
        // Verify contains the message number (1)
        assertTrue(hash.contains(":1:"));
        
        // Print hash for verification
        System.out.println("Generated Hash: " + hash);
    }
}