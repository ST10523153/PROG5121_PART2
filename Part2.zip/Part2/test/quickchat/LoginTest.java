package quickchat;

// Import JUnit testing framework classes
import org.junit.Before;      // @Before annotation - runs before each test
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
import part2.Login;

/**
 * LoginTest Class
 * Purpose: Unit tests for Login class functionality
 * Ensures all validation and authentication methods work correctly
 */
public class LoginTest {
    
    // Test object that will be used by all test methods
    private Login login;
    
    // ============ SETUP METHOD ============
    /**
     * @Before annotation - this method runs BEFORE every test method
     * Creates a fresh Login object for each test to ensure isolation
     */
    @Before
    public void setUp() {
        // Create a new Login instance before each test
        login = new Login();
    }
    
    // ============ TEST 1: Username Correctly Formatted ============
    /**
     * Tests that a valid username passes validation
     * Expected: Success message with welcome
     */
    @Test
    public void testUsernameCorrectlyFormatted() {
        // First register a user with valid username
        login.registerUser("kyl_1", "Ch&sec@ke99!", "John", "Doe", "+27838968976");
        
        // Try to login with same credentials
        String result = login.returnLoginStatus("kyl_1", "Ch&sec@ke99!");
        
        // assertEquals(expected, actual) - test passes if they match
        assertEquals("Welcome John, Doe it is great to see you again.", result);
    }
    
    // ============ TEST 2: Username Incorrectly Formatted ============
    /**
     * Tests that an invalid username returns correct error message
     * Invalid because: no underscore and too long
     */
    @Test
    public void testUsernameIncorrectlyFormatted() {
        // Try to register with invalid username
        String result = login.registerUser("kyle!!!!!!!", "Ch&sec@ke99!", "John", "Doe", "+27838968976");
        
        // Verify error message matches expected
        assertEquals("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.", result);
    }
    
    // ============ TEST 3: Password Meets Complexity ============
    /**
     * Tests that a valid password passes complexity check
     */
    @Test
    public void testPasswordMeetsComplexity() {
        // Check password complexity directly
        boolean result = login.checkPasswordComplexity("Ch&sec@ke99!");
        
        // assertTrue(test) - test passes if result is true
        assertTrue(result);
    }
    
    // ============ TEST 4: Password Does NOT Meet Complexity ============
    /**
     * Tests that weak password returns error message
     * Password "password" fails because: no capital, no number, no special char
     */
    @Test
    public void testPasswordDoesNotMeetComplexity() {
        // Try to register with weak password
        String result = login.registerUser("kyl_1", "password", "John", "Doe", "+27838968976");
        
        // Verify error message
        assertEquals("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", result);
    }
    
    // ============ TEST 5: Cell Phone Correctly Formatted ============
    /**
     * Tests that valid South African cell number is accepted
     * Format: +27 followed by 9 digits
     */
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        // Register with valid phone number
        String result = login.registerUser("kyl_1", "Ch&sec@ke99!", "John", "Doe", "+27838968976");
        
        // Verify success
        assertEquals("User registered successfully.", result);
    }
    
    // ============ TEST 6: Cell Phone Incorrectly Formatted ============
    /**
     * Tests that invalid phone number returns error
     * Invalid because: missing + and international code
     */
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        // Try to register with local number (no country code)
        String result = login.registerUser("kyl_1", "Ch&sec@ke99!", "John", "Doe", "08966553");
        
        // Verify error message
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", result);
    }
    
    // ============ TEST 7: Login Successful ============
    /**
     * Tests that correct credentials allow login
     */
    @Test
    public void testLoginSuccessful() {
        // Register first
        login.registerUser("kyl_1", "Ch&sec@ke99!", "John", "Doe", "+27838968976");
        
        // Attempt login with correct credentials
        boolean result = login.loginUser("kyl_1", "Ch&sec@ke99!");
        
        // Verify login returns true
        assertTrue(result);
    }
    
    // ============ TEST 8: Login Failed ============
    /**
     * Tests that incorrect credentials are rejected
     */
    @Test
    public void testLoginFailed() {
        // Register first
        login.registerUser("kyl_1", "Ch&sec@ke99!", "John", "Doe", "+27838968976");
        
        // Attempt login with WRONG credentials
        boolean result = login.loginUser("wrong", "wrong");
        
        // assertFalse(test) - passes if result is false
        assertFalse(result);
    }
}