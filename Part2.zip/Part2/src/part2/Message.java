/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part2;

import java.util.Random;
import java.util.Scanner;
import java.util.regex.Pattern;
import org.json.JSONObject;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

import java.util.regex.Pattern;

import java.util.regex.Pattern;

public class Message {
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private static int totalMessagesSent = 0;
    
    // Constructor
    public Message(int messageNumber, String recipient, String messageText) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }
    
    // Generate random 10-digit Message ID
    private String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }
    
    // Method to check if Message ID is not more than 10 characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
    
    // Method to check recipient cell number
    public String checkRecipientCell() {
        String regex = "^\\+[0-9]{1,3}[0-9]{6,10}$";
        if (recipient != null && Pattern.matches(regex, recipient)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
    
    // Method to create Message Hash
    public String createMessageHash() {
        String firstTwoNumbers = messageID.substring(0, 2);
        String[] words = messageText.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        lastWord = lastWord.replaceAll("[^A-Z]", "");
        
        String hash = firstTwoNumbers + ":" + messageNumber + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
    
    // Method to handle sending, storing, or disregarding message
    public String sentMessage() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- Message Options ---");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");
        System.out.print("Choose option (1-3): ");
        
        int choice = scanner.nextInt();
        scanner.nextLine();
        
        switch(choice) {
            case 1:
                totalMessagesSent++;
                return "Message successfully sent";
            case 2:
                return "Press 0 to delete the message";
            case 3:
                storeMessage();
                return "Message successfully stored";
            default:
                return "Invalid option selected";
        }
    }
    
    // Method to store message in JSON file
    public void storeMessage() {
        JSONObject jsonMessage = new JSONObject();
        jsonMessage.put("messageID", messageID);
        jsonMessage.put("messageNumber", messageNumber);
        jsonMessage.put("recipient", recipient);
        jsonMessage.put("messageText", messageText);
        jsonMessage.put("messageHash", messageHash);
        jsonMessage.put("timestamp", System.currentTimeMillis());
        
        try {
            File directory = new File("stored_messages");
            if (!directory.exists()) {
                directory.mkdir();
            }
            
            String filename = "stored_messages/message_" + messageID + ".json";
            try (FileWriter file = new FileWriter(filename)) {
                file.write(jsonMessage.toString(4));
            }
            System.out.println("Message stored in: " + filename);
        } catch (IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }
    
    // Method to display message details
    public String printMessages() {
        return String.format("Message ID: %s\nMessage Hash: %s\nRecipient: %s\nMessage: %s\n",
                            messageID, messageHash, recipient, messageText);
    }
    
    // Method to return total number of messages sent
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }
    
    // Method to validate message length
    public static String validateMessageLength(String message) {
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = message.length() - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce the size.";
        }
    }
    
    // Getters
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public int getMessageNumber() { return messageNumber; }
    
    // Reset counter for testing
    public static void resetCounters() {
        totalMessagesSent = 0;
    }
}