/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package part2;

import javax.lang.model.SourceVersion;

/**
 *
 * @author donge
 */
import java.util.regex.Pattern;

public class Login {
    private String storedUsername;
    private String storedPassword;
    private String storedFirstName;
    private String storedLastName;
    private String storedCellPhone;

    // Method to check username format (underscore and max 5 chars)
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }

    // Method to check cell phone number using regex
    public boolean checkCellPhoneNumber(String phone) {
        String regex = "^\\+[0-9]{1,3}[0-9]{6,10}$";
        return phone != null && Pattern.matches(regex, phone);
    }

    // Registration logic
    public String registerUser(String username, String password, String firstName, 
                               String lastName, String cellPhone) {
        boolean validUsername = checkUserName(username);
        boolean validPassword = checkPasswordComplexity(password);
        
        if (!validUsername) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!validPassword) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        this.storedUsername = username;
        this.storedPassword = password;
        this.storedFirstName = firstName;
        this.storedLastName = lastName;
        this.storedCellPhone = cellPhone;
        
        return "User registered successfully.";
    }

    // Login verification
    public boolean loginUser(String username, String password) {
        return storedUsername != null && storedUsername.equals(username) && 
               storedPassword != null && storedPassword.equals(password);
    }

    // Return login status message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + storedFirstName + ", " + storedLastName + 
                   " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}