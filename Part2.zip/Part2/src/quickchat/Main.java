package quickchat;
// Import required Java libraries
import java.util.Scanner;
import java.util.ArrayList;
import part2.Login;
import part2.Message;

public class Main {
    // ============ STATIC VARIABLES ============
    // Static because they belong to the class, not individual objects
    // These are accessible from all methods in this class
    private static Login loginSystem = new Login();
    private static boolean isLoggedIn = false;
    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<Message> sentMessages = new ArrayList<>();
    
    public static void main(String[] args) {
        // Display welcome banner
        // Multiple print statements create a box effect
        System.out.println("========================================");
        System.out.println("     WELCOME TO QUICKCHAT SYSTEM");
        System.out.println("========================================");
         // Step 1: Handle registration and login
        // If registration/login fails, exit the program
        if (!handleRegistrationAndLogin()) {
            System.out.println("Registration or login failed. Exiting...");
            return;
        }
        // Step 2: If logged in successfully, show the messaging menu
        if (isLoggedIn) {
            showQuickChatMenu();
        }
    }
    
    private static boolean handleRegistrationAndLogin() {
        // === REGISTRATION PHASE ===
        System.out.println("\n--- REGISTRATION ---");
       // Prompt and read username
        System.out.print("Enter username (max 5 chars, must contain _): ");
        String username = scanner.nextLine();
         // Prompt and read password
        System.out.print("Enter password (min 8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();
         // Prompt and read first name
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();
         // Prompt and read last name
        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();
        // Prompt and read cell phone number
        System.out.print("Enter cell phone (+27838968976): ");
        String cellPhone = scanner.nextLine();
        // Call registerUser method and store result message
        String regResult = loginSystem.registerUser(username, password, firstName, lastName, cellPhone);
        System.out.println(regResult);
        // If registration failed (not success message), return false
        if (!regResult.equals("User registered successfully.")) {
            return false;
        }
         // === LOGIN PHASE ===
        System.out.println("\n--- LOGIN ---");
        // Prompt for login credentials
        System.out.print("Enter username: ");
        String loginUser = scanner.nextLine();
        
        System.out.print("Enter password: ");
        String loginPass = scanner.nextLine();
        // Attempt login and get status message
        String loginStatus = loginSystem.returnLoginStatus(loginUser, loginPass);
        System.out.println(loginStatus);
         // Check if login was successful (message contains "Welcome")
        if (loginStatus.contains("Welcome")) {
            isLoggedIn = true;
            return true;
        }
        
        return false;
    }
    
    private static void showQuickChatMenu() {
       // Display welcome message after successful login
        System.out.println("\n========================================");
        System.out.println("     WELCOME TO QUICKCHAT");
        System.out.println("========================================");
         // Ask how many messages user wants to create
        System.out.print("\nHow many messages do you want to create? ");
        int numMessages = scanner.nextInt();
        scanner.nextLine();
         // Menu loop control variable
        boolean running = true;
         // While loop - continues until user chooses to quit
        while (running) {
           // Display menu options
            System.out.println("\n--- QUICKCHAT MENU ---");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages (Coming Soon)");
            System.out.println("3. Quit");
            System.out.print("Choose option (1-3): ");
             // Read user's menu choice
            int choice = scanner.nextInt();
            scanner.nextLine();
             // Switch statement handles different menu choices
            switch (choice) {
                case 1: // Send Messages
                    sendMessages(numMessages);
                    break; // Exit switch, return to menu loop
                case 2: // Coming Soon feature
                    System.out.println("\nComing Soon - This feature is still in development.");
                    break;
                case 3: // Quit
                    running = false; // Set flag to false to exit loop
                    System.out.println("\nThank you for using QuickChat. Goodbye!");
                    break;
                default:// Invalid choice
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        // Display final summary before exiting
        System.out.println("\n========================================");
        System.out.println("FINAL SUMMARY");
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
        System.out.println("========================================");
    }
    
    private static void sendMessages(int maxMessages) {
        for (int i = 0; i < maxMessages; i++) {
          // i+1 for human-readable (1-based)
            System.out.println("\n========================================");
            System.out.println("MESSAGE " + (i + 1) + " OF " + maxMessages);
            System.out.println("========================================");
            // Get recipient phone number
            System.out.print("Enter recipient (+27718693002): ");
            String recipient = scanner.nextLine();
            // Get message content
            System.out.print("Enter your message (max 250 chars): ");
            String messageText = scanner.nextLine();
            // Validate message length
            String validationResult = Message.validateMessageLength(messageText);
            System.out.println(validationResult);
            // Only proceed if message length is valid
            if (validationResult.equals("Message ready to send.")) {
                Message msg = new Message(i + 1, recipient, messageText);
                 // Validate recipient phone number
                String recipientCheck = msg.checkRecipientCell();
                System.out.println(recipientCheck);
                // Only proceed if recipient number is valid
                if (recipientCheck.equals("Cell phone number successfully captured.")) {
                    String sendResult = msg.sentMessage();
                    System.out.println(sendResult);
                    // If user chose to send, store and display message
                    if (sendResult.equals("Message successfully sent")) {
                        sentMessages.add(msg);
                        System.out.println("\n--- MESSAGE DETAILS ---");
                        System.out.println(msg.printMessages());
                    }
                }
            }
        }
        // Display completion summary
        System.out.println("\n========================================");
        System.out.println("All messages processed!");
        System.out.println("Total messages sent: " + Message.returnTotalMessages());
        System.out.println("========================================");
    }
}